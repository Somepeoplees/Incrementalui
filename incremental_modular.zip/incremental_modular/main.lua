-- Main Entry Point
loadstring(readfile("Incremental/init.lua"))()