-- Automation Logic (auto tap, auto convert)

local core = loadstring(readfile("Incremental/core.lua"))()
local currencies = core.currencies
local upgrades = core.upgrades

spawn(function()
    while wait(1) do
        if upgrades.autoClick.level > 0 then
            currencies.Energy += upgrades.tapPower.level * upgrades.autoClick.level
        end
    end
end)

return {}