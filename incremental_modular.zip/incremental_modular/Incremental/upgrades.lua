-- Upgrade Manager

local core = loadstring(readfile("Incremental/core.lua"))()
local currencies = core.currencies
local upgrades = core.upgrades

local function canAfford(cost)
    return currencies.Coins >= cost
end

local function buyUpgrade(name)
    local upgrade = upgrades[name]
    if upgrade and canAfford(upgrade.baseCost * upgrade.level) then
        currencies.Coins -= upgrade.baseCost * upgrade.level
        upgrade.level += 1
        return true
    end
    return false
end

return {
    buyUpgrade = buyUpgrade,
    getUpgrades = function() return upgrades end
}