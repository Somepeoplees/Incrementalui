-- Core Variables and Upgrades

local currencies = {
    Energy = 0,
    Coins = 0,
    Gems = 0,
}

local upgrades = {
    tapPower = {level = 1, baseCost = 10},
    coinRate = {level = 1, baseCost = 20},
    autoClick = {level = 0, baseCost = 50},
    convertRate = {level = 1, baseCost = 100},
}

return {
    currencies = currencies,
    upgrades = upgrades
}