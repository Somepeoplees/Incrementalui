-- Initialization Script
if _G.IncrementalGame then return end
_G.IncrementalGame = true

local Modules = {}
local function include(name)
    Modules[name] = loadstring(readfile("Incremental/" .. name .. ".lua"))()
end

include("core")
include("ui")
include("tool")
include("tick")