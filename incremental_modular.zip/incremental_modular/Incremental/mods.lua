-- Mod Loader

local mods = {}

local function runMod(scriptStr)
    local success, mod = pcall(loadstring(scriptStr))
    if success then
        table.insert(mods, mod)
        local ok, err = pcall(mod)
        if not ok then warn("Mod error:", err) end
    else
        warn("Invalid mod script")
    end
end

return {
    runMod = runMod,
    listMods = function() return mods end
}