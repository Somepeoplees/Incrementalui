-- Tool Creation & Toggle UI

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local function giveTool()
    local tool = Instance.new("Tool")
    tool.Name = "Incremental Device"
    tool.RequiresHandle = false
    tool.Parent = LocalPlayer:WaitForChild("Backpack")
    
    local gui = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("IncrementalUI")
    tool.Equipped:Connect(function()
        gui.Enabled = true
    end)
    
    tool.Unequipped:Connect(function()
        gui.Enabled = false
    end)
end

giveTool()

return {}