-- Milestone Tracker

local core = loadstring(readfile("Incremental/core.lua"))()
local currencies = core.currencies

local milestones = {
    {type="Energy", amount=1000, reward=function() core.upgrades.tapPower.level += 1 end, claimed=false},
    {type="Coins", amount=5000, reward=function() core.upgrades.coinRate.level += 1 end, claimed=false},
}

local function checkMilestones()
    for _, m in ipairs(milestones) do
        if not m.claimed and currencies[m.type] >= m.amount then
            m.reward()
            m.claimed = true
            print("Milestone achieved: " .. m.type .. " >= " .. m.amount)
        end
    end
end

spawn(function()
    while wait(5) do
        checkMilestones()
    end
end)

return {
    milestones = milestones
}