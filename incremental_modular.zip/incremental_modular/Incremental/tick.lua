-- Passive Tick Loop

local core = loadstring(readfile("Incremental/core.lua"))()
local currencies = core.currencies
local upgrades = core.upgrades

spawn(function()
    while wait(1) do
        currencies.Coins += upgrades.coinRate.level
    end
end)

return {}